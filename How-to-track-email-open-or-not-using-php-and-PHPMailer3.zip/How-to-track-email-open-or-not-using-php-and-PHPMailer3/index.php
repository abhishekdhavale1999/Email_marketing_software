<?php
$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");
$base_url = 'http://localhost/How-to-track-email-open-or-not-using-php-and-PHPMailer/';
$message = '';
$success = true; 

if(isset($_POST["send"])) {
    require_once 'vendor/autoload.php';
    
    $mail = new PHPMailer\PHPMailer\PHPMailer;
    $mail->IsSMTP();
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPAuth = true;
    $mail->Username = "abhishekdhavale121@gmail.com";
    $mail->Password = "kfvb wkrj klja uzfx";
    $mail->SMTPSecure = "tls";
    $mail->Port = 587;
    $mail->SetFrom("abhishekdhavale121@gmail.com", "Abhishek");
    
    $email_subject = $_POST['email_subject'];
    $email_body = $_POST['email_body'];
    
    $receiver_emails_input = $_POST['receiver_emails'];
    $receiver_emails_array = explode(',', $receiver_emails_input);
    
    if(isset($_FILES['email_file']) && $_FILES['email_file']['error'] === UPLOAD_ERR_OK) {
        $file_info = pathinfo($_FILES['email_file']['name']);
        if(strtolower($file_info['extension']) == 'csv') {
            $file = fopen($_FILES['email_file']['tmp_name'], 'r');
            if($file) {
                $receiver_emails = array();
                while(($data = fgetcsv($file)) !== FALSE) {
                    foreach($data as $email) {
                        $email = trim($email);
                        if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
                            $receiver_emails[] = $email;
                        }
                    }
                }
                fclose($file);
            } else {
                $success = false;
                $message .= '<label class="text-danger">Failed to open the uploaded file</label><br>';
            }

            foreach ($receiver_emails as $receiver_email) {
                sendEmail($receiver_email, $email_subject, $email_body, $mail, $base_url, $connect, $success, $message);
            }
        } else {
            $success = false;
            $message .= '<label class="text-danger">Invalid file type. Please upload a CSV file</label><br>';
        }
    } else {
        $success = false;
        $message .= '<label class="text-danger"></label><br>';
    }

    foreach ($receiver_emails_array as $receiver_email) {
        $receiver_email = trim($receiver_email); 
        sendEmail($receiver_email, $email_subject, $email_body, $mail, $base_url, $connect, $success, $message);
    }
    
   if($success) {
    $message = '<label class="text-success">Emails sent successfully</label>';
  } elseif (!empty($message)) {
    $message = '<label class="text-danger">' . $message . '</label>';
  }


}

function sendEmail($receiver_email, $email_subject, $email_body, $mail, $base_url, $connect, &$success, &$message) {
    if (filter_var($receiver_email, FILTER_VALIDATE_EMAIL)) {
        $track_code = uniqid() . '_' . time();
        $mail->ClearAllRecipients();
        $mail->AddAddress($receiver_email);
        $mail->WordWrap = 50;
        $mail->isHTML(true);
        $mail->Subject = $email_subject;

       
        $tracking_link = $base_url . 'email_track.php?code=' . $track_code; 

       
        $email_body_with_tracking = $email_body . '<img src="' . $tracking_link . '" alt="Tracking Pixel">';
        $mail->Body = $email_body_with_tracking;

        if (!$mail->Send()) {
            $success = false;
            $message .= '<label class="text-danger">Failed to send email to ' . $receiver_email . '</label><br>';
        } else {
            $data = array(
                ':email_subject'    => $email_subject,
                ':email_body'       => $email_body,
                ':email_address'    => $receiver_email,
                ':email_track_code' => $track_code
            );

            $query1 = "
                INSERT INTO email_data 
                (email_subject, email_body, email_address, email_track_code) 
                VALUES 
                (:email_subject, :email_body, :email_address, :email_track_code)
            ";
            $statement1 = $connect->prepare($query1);

            if (!$statement1->execute($data)) {
                $success = false;
                $message .= '<label class="text-danger">Failed to save email data for ' . $receiver_email . '</label><br>';
            } else {
                
                $message .= '<label class="text-success">Email sent successfully to ' . $receiver_email . '</label><br>';
                
                $query2 = "
                    INSERT INTO email_track 
                    (email_track_code, email_status, email_open_datetime) 
                    VALUES 
                    (:email_track_code, :email_status, NOW())
                ";
                $statement2 = $connect->prepare($query2);

                if (!$statement2->execute([':email_track_code' => $track_code, ':email_status' => 'not open'])) {
                    $success = false;
                    $message .= '<label class="text-danger">Failed to track email for ' . $receiver_email . '</label><br>';
                }
            }
        }
    } else {
        $success = false;
        $message .= '<label class="text-danger">' . $receiver_email . ' is not a valid email address</label><br>';
    }
}

function fetch_email_track_data($connect) {
    $query = "
        SELECT 
            email_data.email_subject,
            email_data.email_address,
            email_data.email_body,
            email_data.email_track_code,
            email_track.email_status,
            MAX(email_track.email_open_datetime) AS email_open_datetime 
        FROM 
            email_data 
        LEFT JOIN 
            email_track ON email_track.email_track_code = email_data.email_track_code 
        GROUP BY 
            email_data.email_subject,
            email_data.email_address,
            email_data.email_body,
            email_data.email_track_code,
            email_track.email_status 
        ORDER BY 
            email_open_datetime DESC
    ";

    $statement = $connect->prepare($query);
    $statement->execute();
    $result = $statement->fetchAll();
    $total_row = $statement->rowCount();
    $output = '';

  
    if($total_row > 0) {
        $output .= '<div class="table-responsive">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th width="25%">Email</th>
                                    <th width="40%">Subject</th>
                                    <th width="10%">Status</th>
                                    <th width="15%">Open Datetime</th>
                                    <th width="10%">POC</th>
                                </tr>
                            </thead>
                            <tbody>';

   
        foreach($result as $row) {
            $status = ($row['email_status'] == 'open') ? '<span class="label label-success">Open</span>' : '<span class="label label-danger">Not Open</span>';
            $output .= '<tr>
                            <td>'.$row["email_address"].'</td>
                            <td>'.$row["email_subject"].'</td>
                            <td>'.$status.'</td>
                            <td>'.$row["email_open_datetime"].'</td>
                            <td>
                                <!-- Button to display email template -->
                                <button class="btn btn-info display-template" data-template="'.htmlspecialchars($row["email_body"]).'">POC</button>
                            </td>
                        </tr>';
        }

        $output .= '</tbody>
                    <tfoot>
                        <tr>
                            <th width="25%">Email</th>
                            <th width="40%">Subject</th>
                            <th width="10%">Status</th>
                            <th width="15%">Open Datetime</th>
                            <th width="10%">POC</th>
                        </tr>
                    </tfoot>
                </table>
            </div>';
    } else {
        $output .= '<div class="table-responsive">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th width="25%">Email</th>
                                    <th width="40%">Subject</th>
                                    <th width="10%">Status</th>
                                    <th width="15%">Open Datetime</th>
                                    <th width="10%">POC</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="5" align="center"><strong>No Email Send Data Found</strong></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>';
    }

    return $output;
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Track Email Open or not</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <script src="js/jquery.min.js"></script>
    <link rel="stylesheet" href="css/jquery.dataTables.min.css">
    <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <style>
        .email-template {
            display: none; 
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <br />
    <div class="container">
        <h3 align="center">Intent amplify Email tracking</h3>
        <br />
        <?php echo $message; ?>
        <form method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label>Email Subject</label>
                <input type="text" name="email_subject" class="form-control" placeholder="Subject" required />
            </div>
            <div class="form-group">
                <label>Enter Receiver Email (Separate multiple emails by commas)</label>
                <input type="text" name="receiver_emails" class="form-control" placeholder="Enter email addresses separated by commas"/>
            </div>
            <div class="form-group">
                <label>Upload File (CSV format)</label>
                <input type="file" name="email_file" accept=".csv" class="form-control" />
            </div>
            <div class="form-group">
                <label>Email Body</label>
                <textarea name="email_body" required rows="5" class="form-control" placeholder="Body"></textarea>
            </div>
            <div class="form-group">
                <input type="submit" name="send" class="btn btn-info" value="Send Email" />
            </div>
        </form>
        <br />
        <h4 align="center">Open Status Of All Emails</h4>
        <?php echo fetch_email_track_data($connect); ?>
    </div>

    <div class="email-template">
        <h4>Email Template</h4>
    </div>

    <script>
        $(document).ready(function(){
            $('.display-template').click(function(){
                $('.email-template').html($(this).data('template')).toggle();
            });
        });
    </script>
</body>
</html>

