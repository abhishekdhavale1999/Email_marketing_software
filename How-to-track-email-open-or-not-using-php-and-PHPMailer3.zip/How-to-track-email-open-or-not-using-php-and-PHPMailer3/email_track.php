<?php
$connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");

if(isset($_GET['code'])) {
    $code = $_GET['code'];

    // Check if the track code exists in the email_data table
    $query = "SELECT * FROM email_data WHERE email_track_code = :code";
    $statement = $connect->prepare($query);
    $statement->execute(['code' => $code]);
    $count = $statement->rowCount();

    if($count > 0) {
        // Update the status in the email_track table
        $updateQuery = "UPDATE email_track SET email_status = 'open', email_open_datetime = NOW() WHERE email_track_code = :code";
        $updateStatement = $connect->prepare($updateQuery);
        $updateStatement->execute(['code' => $code]);
    } else {
        // Handle the case where the track code is not found in the email_data table
        error_log("Track code not found in email_data table: " . $code);
    }
}
?>
