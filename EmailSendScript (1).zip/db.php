<?php
$con=mysqli_connect('HOST','DB_USERNAME','DB_PASSWORD','DB_NAME');
?>