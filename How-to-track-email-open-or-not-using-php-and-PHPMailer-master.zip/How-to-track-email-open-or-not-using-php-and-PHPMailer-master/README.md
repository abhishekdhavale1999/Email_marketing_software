# How-to-track-email-open-or-not-using-php-and-PHPMailer
 This simple PHP script will allows you to track open or not HTML emails. This feature you can also add in your web application also if you have continuously send email to your customer for reach. Above you can find step by step source code for email open tracking PHP script.

# Note If "Less secure app access" is turned off for your Gmail account, you have to turn it on. If You are using Gmail_SMTP
1.Create database "email_track_database".

2.Import email_track_database.sql file.

3.Provide your username and password in index.php file. 

# IMPORTANT - Make sure you are uploading all files on your Website.May be for localhost it will not work because of url .

# Snapshot :

![Image of User_interface](https://github.com/pradipkumarraushan/How-to-track-email-open-or-not-using-php-and-PHPMailer/blob/master/Snapshot.JPG)

![Image of User_interface](https://github.com/pradipkumarraushan/How-to-track-email-open-or-not-using-php-and-PHPMailer/blob/master/History_Logs.JPG)

# Database Design

![Image of db](https://github.com/pradipkumarraushan/How-to-track-email-open-or-not-using-php-and-PHPMailer/blob/master/Databse%20Design.JPG)
